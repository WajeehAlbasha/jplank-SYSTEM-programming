int a(int i, int j)
{
  int k;

  k = (i+2)*(j-5);
  return k;
}

int main()
{
  int i;

  i = a(44, 22);
}

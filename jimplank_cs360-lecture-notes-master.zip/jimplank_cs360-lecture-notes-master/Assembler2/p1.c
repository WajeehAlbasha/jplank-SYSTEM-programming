int a()
{
  return 1;
}

int main()
{
  int i;

  i = a();
}

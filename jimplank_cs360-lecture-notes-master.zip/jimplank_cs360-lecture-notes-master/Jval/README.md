# Libfdr: The Jval Library.

James S. Plank

My lecture notes are in HTML rather than Markdown, so to read them,
you'll have to [read them from my UTK web site](http://web.eecs.utk.edu/~plank/plank/classes/cs360/360/notes/Jval/index.html).  I store them here on the repo, so the site at UTK is 
kept up to date.


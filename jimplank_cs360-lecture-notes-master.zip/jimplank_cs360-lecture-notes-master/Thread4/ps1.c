#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "printqsim.h"

void initialize_v(Spq *s)
{
  s->v = NULL;
}

void submit_job(Spq *s, Job *j)
{
  return;
}

Job *get_print_job(Spq *s)
{
 
  return NULL;
}

int main()
{
  int i, j, *jp;

  jp = &j;
  j = 15;
  i = *jp;
}

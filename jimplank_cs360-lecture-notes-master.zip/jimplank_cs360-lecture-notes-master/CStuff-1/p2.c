#include <stdio.h>
#include <stdlib.h>

char s1[15];

int main(int argc, char **argv)
{
  char s2[4];
  
  s2 = "Jim";
  exit(0);
}
